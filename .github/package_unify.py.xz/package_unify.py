from __future__ import annotations

import json
import re
import shutil
from collections import defaultdict
from pathlib import Path

ROOT = Path.cwd()
MAIN = ROOT / 'src/main/java'
TEST = ROOT / 'src/test/java'
SRC_ROOTS = [MAIN, TEST]

PACKAGE_RE = re.compile(r'(?m)^package\s+([\w.]+);')
# Package-only tombstone sources exist, so filename is the fallback type name.
TYPE_RE = re.compile(r'(?m)^(?:public\s+)?(?:(?:final|abstract|sealed|non-sealed)\s+)*(?:class|record|interface|enum)\s+(\w+)')
IMPORT_RE = re.compile(r'(?m)^import\s+(static\s+)?([\w.*]+);')

FORBIDDEN_ROOTS = (
    'com.redslovesgames.tidetraits',
    'com.redslovesgames.tideteamjournal',
    'com.redslovesgames.tideboundcompatibility',
)
V2 = 'com.redslovesgames.tideborne.fishing.v2'


def strip_test_suffix(name: str) -> str:
    for suffix in ('GameTests', 'Tests', 'Test'):
        if name.endswith(suffix):
            return name[:-len(suffix)]
    return name


def fishing_v2_root_target(cls: str) -> str:
    base = strip_test_suffix(cls)
    if cls == 'FreshWorldRegressionGameTests':
        # White-box GameTest directly exercises package-private TraitMomentumState.
        return 'com.redslovesgames.tideborne.fishing.specimen'
    if base == 'LegacyFishMigrationService':
        return 'com.redslovesgames.tideborne.migration.legacy'
    if base == 'TideFishingLineModifiers':
        return 'com.redslovesgames.tideborne.fishing.tide'

    specimen_exact = {
        'CanonicalRarity', 'BodyTypeGenerator', 'ConditionGenerator', 'FishScoreV2Service',
        'LogNormalSizeDistribution', 'NoPhysicalSizeDistribution', 'NormalDistributionMath',
        'PigmentationGenerator', 'SizeDistribution', 'SpecimenData', 'SpecimenGenerator',
        'SpecimenQualityService', 'TraitLuckProbabilityService', 'TraitMomentumProgression',
        'TraitMomentumState', 'TraitMomentumStorage', 'TraitProbabilityService', 'TraitRandom',
    }
    gear_exact = {
        'FishingGearEffects', 'FishingGearModifiers', 'FishingGearRegistry',
    }
    if base in specimen_exact:
        return 'com.redslovesgames.tideborne.fishing.specimen'
    if base in gear_exact:
        return 'com.redslovesgames.tideborne.fishing.gear'
    return 'com.redslovesgames.tideborne.fishing'


def fishing_integration_target(cls: str) -> str:
    base = strip_test_suffix(cls)
    if base in {'CanonicalCatchStateManager', 'CanonicalSpecimenStorage', 'CatchSeedDeriver', 'LegacyItemStackMigration', 'CanonicalEntityTransfer'}:
        return 'com.redslovesgames.tideborne.fishing.specimen'
    if base in {'JournalSpecimenNetworkCodec', 'JournalSpecimenStore', 'CanonicalSpecimenRecordIndexer', 'LegacyJournalMigration', 'LegacyJournalPersistence'}:
        # LegacyJournalMigrationTest intentionally stays here for package-private migrateLegacyRecord(...).
        return 'com.redslovesgames.tideborne.journal'
    if base in {'TideFishingContextAdapter', 'TideSpeciesProfileAdapter', 'TideSpeciesSelectionBridge', 'CrateFishProgressionBridge'}:
        return 'com.redslovesgames.tideborne.fishing.tide'
    if base.startswith('Legacy'):
        return 'com.redslovesgames.tideborne.migration.legacy'
    return 'com.redslovesgames.tideborne.fishing'


def map_package(pkg: str, cls: str) -> str:
    # Existing Tideborne packages outside fishing.v2 already satisfy the root-unification goal.
    if pkg == 'com.redslovesgames.tideborne.migration':
        return 'com.redslovesgames.tideborne.migration.legacy'

    if pkg == V2:
        return fishing_v2_root_target(cls)
    if pkg.startswith(V2 + '.'):
        tail = pkg[len(V2) + 1:]
        if tail == 'integration':
            return fishing_integration_target(cls)
        if tail == 'gametest' or tail.startswith('gametest.'):
            suffix = tail[len('gametest'):]
            return 'com.redslovesgames.tideborne.fishing.gametest' + suffix
        if tail == 'debug' or tail.startswith('debug.'):
            suffix = tail[len('debug'):]
            return 'com.redslovesgames.tideborne.fishing.debug' + suffix
        if tail == 'simulation' or tail.startswith('simulation.'):
            suffix = tail[len('simulation'):]
            return 'com.redslovesgames.tideborne.fishing.simulation' + suffix
        return 'com.redslovesgames.tideborne.fishing.' + tail

    if pkg == 'com.redslovesgames.tidetraits':
        return 'com.redslovesgames.tideborne.fishing'
    if pkg.startswith('com.redslovesgames.tidetraits.'):
        tail = pkg[len('com.redslovesgames.tidetraits.'):]
        if tail == 'trait' or tail.startswith('trait.'):
            suffix = tail[len('trait'):]
            return 'com.redslovesgames.tideborne.fishing.specimen.legacy' + suffix
        if tail == 'catching' or tail.startswith('catching.'):
            suffix = tail[len('catching'):]
            return 'com.redslovesgames.tideborne.fishing.specimen' + suffix
        if tail == 'fish' or tail.startswith('fish.'):
            suffix = tail[len('fish'):]
            return 'com.redslovesgames.tideborne.fishing.specimen' + suffix
        if tail == 'entity' or tail.startswith('entity.'):
            suffix = tail[len('entity'):]
            return 'com.redslovesgames.tideborne.fishing.specimen' + suffix
        if tail == 'component' or tail.startswith('component.'):
            suffix = tail[len('component'):]
            return 'com.redslovesgames.tideborne.registry' + suffix
        if tail == 'discovery' or tail.startswith('discovery.'):
            suffix = tail[len('discovery'):]
            return 'com.redslovesgames.tideborne.discovery' + suffix
        if tail == 'compat.multiplayer' or tail.startswith('compat.multiplayer.'):
            suffix = tail[len('compat.multiplayer'):]
            return 'com.redslovesgames.tideborne.discovery.multiplayer' + suffix
        if tail == 'satchel' or tail.startswith('satchel.'):
            suffix = tail[len('satchel'):]
            return 'com.redslovesgames.tideborne.satchel' + suffix
        if tail == 'client.gui.journal' or tail.startswith('client.gui.journal.'):
            suffix = tail[len('client.gui.journal'):]
            return 'com.redslovesgames.tideborne.journal.client' + suffix
        if tail == 'client.gui.satchel' or tail.startswith('client.gui.satchel.'):
            suffix = tail[len('client.gui.satchel'):]
            return 'com.redslovesgames.tideborne.satchel.client' + suffix
        if tail == 'client.render' or tail.startswith('client.render.'):
            suffix = tail[len('client.render'):]
            return 'com.redslovesgames.tideborne.presentation.render' + suffix
        if tail == 'client' or tail.startswith('client.'):
            suffix = tail[len('client'):]
            return 'com.redslovesgames.tideborne.presentation.client' + suffix
        if tail == 'command' or tail.startswith('command.'):
            suffix = tail[len('command'):]
            return 'com.redslovesgames.tideborne.command' + suffix
        if tail == 'config' or tail.startswith('config.'):
            suffix = tail[len('config'):]
            return 'com.redslovesgames.tideborne.config' + suffix
        if tail == 'gametest' or tail.startswith('gametest.'):
            suffix = tail[len('gametest'):]
            return 'com.redslovesgames.tideborne.fishing.gametest' + suffix
        if tail == 'mixin.client' or tail.startswith('mixin.client.'):
            suffix = tail[len('mixin.client'):]
            return 'com.redslovesgames.tideborne.mixin.specimen.client' + suffix
        if tail == 'mixin' or tail.startswith('mixin.'):
            suffix = tail[len('mixin'):]
            return 'com.redslovesgames.tideborne.mixin.specimen' + suffix
        if tail == 'resource' or tail.startswith('resource.'):
            suffix = tail[len('resource'):]
            return 'com.redslovesgames.tideborne.presentation.resource' + suffix
        raise RuntimeError(f'Unclassified Tide Traits package {pkg} ({cls})')

    if pkg == 'com.redslovesgames.tideteamjournal':
        return 'com.redslovesgames.tideborne.journal'
    if pkg.startswith('com.redslovesgames.tideteamjournal.'):
        tail = pkg[len('com.redslovesgames.tideteamjournal.'):]
        if tail == 'client' or tail.startswith('client.'):
            suffix = tail[len('client'):]
            return 'com.redslovesgames.tideborne.journal.client' + suffix
        if tail == 'mixin.client' or tail.startswith('mixin.client.'):
            suffix = tail[len('mixin.client'):]
            return 'com.redslovesgames.tideborne.mixin.journal.client' + suffix
        if tail == 'mixin' or tail.startswith('mixin.'):
            suffix = tail[len('mixin'):]
            return 'com.redslovesgames.tideborne.mixin.journal' + suffix
        return 'com.redslovesgames.tideborne.journal.' + tail

    if pkg == 'com.redslovesgames.tideboundcompatibility':
        return 'com.redslovesgames.tideborne.compat'
    if pkg.startswith('com.redslovesgames.tideboundcompatibility.'):
        tail = pkg[len('com.redslovesgames.tideboundcompatibility.'):]
        if tail == 'compat.apex' or tail.startswith('compat.apex.'):
            suffix = tail[len('compat.apex'):]
            return 'com.redslovesgames.tideborne.compat.apex' + suffix
        if tail == 'client' or tail.startswith('client.'):
            suffix = tail[len('client'):]
            return 'com.redslovesgames.tideborne.presentation.client' + suffix
        if tail == 'config' or tail.startswith('config.'):
            suffix = tail[len('config'):]
            return 'com.redslovesgames.tideborne.config' + suffix
        if tail == 'entity' or tail.startswith('entity.'):
            suffix = tail[len('entity'):]
            return 'com.redslovesgames.tideborne.ecosystem' + suffix
        if tail == 'fishing' or tail.startswith('fishing.'):
            suffix = tail[len('fishing'):]
            if strip_test_suffix(cls) == 'SharkCatchLoss':
                return 'com.redslovesgames.tideborne.ecosystem' + suffix
            return 'com.redslovesgames.tideborne.fishing.gear' + suffix
        if tail == 'item' or tail.startswith('item.'):
            suffix = tail[len('item'):]
            if strip_test_suffix(cls) == 'ChumBucketItem':
                return 'com.redslovesgames.tideborne.ecosystem' + suffix
            return 'com.redslovesgames.tideborne.fishing.gear' + suffix
        if tail == 'mixin.apex' or tail.startswith('mixin.apex.'):
            suffix = tail[len('mixin.apex'):]
            return 'com.redslovesgames.tideborne.mixin.compat.apex' + suffix
        if tail == 'mixin' or tail.startswith('mixin.'):
            suffix = tail[len('mixin'):]
            return 'com.redslovesgames.tideborne.mixin.tide' + suffix
        if tail == 'network' or tail.startswith('network.'):
            suffix = tail[len('network'):]
            return 'com.redslovesgames.tideborne.network' + suffix
        if tail == 'registry' or tail.startswith('registry.'):
            suffix = tail[len('registry'):]
            return 'com.redslovesgames.tideborne.registry' + suffix
        return 'com.redslovesgames.tideborne.compat.' + tail

    return pkg


def strip_comments_and_literals(text: str) -> str:
    """Preserve newlines/rough token boundaries while removing comments and literals."""
    out = []
    i = 0
    n = len(text)
    state = 'code'
    while i < n:
        c = text[i]
        nxt = text[i+1] if i + 1 < n else ''
        if state == 'code':
            if c == '/' and nxt == '/':
                out.extend('  '); i += 2; state = 'line'; continue
            if c == '/' and nxt == '*':
                out.extend('  '); i += 2; state = 'block'; continue
            if c == '"':
                out.append(' '); i += 1; state = 'string'; continue
            if c == "'":
                out.append(' '); i += 1; state = 'char'; continue
            out.append(c); i += 1; continue
        if state == 'line':
            if c == '\n': out.append('\n'); state = 'code'
            else: out.append(' ')
            i += 1; continue
        if state == 'block':
            if c == '*' and nxt == '/': out.extend('  '); i += 2; state = 'code'; continue
            out.append('\n' if c == '\n' else ' '); i += 1; continue
        if state in ('string', 'char'):
            quote = '"' if state == 'string' else "'"
            if c == '\\':
                out.append(' '); i += 1
                if i < n:
                    out.append('\n' if text[i] == '\n' else ' '); i += 1
                continue
            if c == quote:
                out.append(' '); i += 1; state = 'code'; continue
            out.append('\n' if c == '\n' else ' '); i += 1
    return ''.join(out)


class Unit:
    def __init__(self, path: Path, root: Path, text: str, pkg: str, cls: str):
        self.path = path
        self.root = root
        self.text = text
        self.pkg = pkg
        self.cls = cls
        self.new_pkg = map_package(pkg, cls)
        self.old_fqcn = f'{pkg}.{cls}'
        self.new_fqcn = f'{self.new_pkg}.{cls}'
        self.new_path = root / Path(*self.new_pkg.split('.')) / path.name


units: list[Unit] = []
for root in SRC_ROOTS:
    for path in sorted(root.rglob('*.java')):
        text = path.read_text(encoding='utf-8')
        pm = PACKAGE_RE.search(text)
        if not pm:
            continue
        tm = TYPE_RE.search(strip_comments_and_literals(text))
        cls = tm.group(1) if tm else path.stem
        units.append(Unit(path, root, text, pm.group(1), cls))

fqcn_map = {u.old_fqcn: u.new_fqcn for u in units if u.old_fqcn != u.new_fqcn}
path_map = {u.path.relative_to(ROOT).as_posix(): u.new_path.relative_to(ROOT).as_posix() for u in units if u.path != u.new_path}

# Collision safety across each source set.
seen = {}
for u in units:
    key = (u.root, u.new_fqcn)
    if key in seen and seen[key] != u.path:
        raise RuntimeError(f'Collision at {u.new_fqcn}: {seen[key]} vs {u.path}')
    seen[key] = u.path

old_pkg_classes: dict[str, dict[str, Unit]] = defaultdict(dict)
for u in units:
    old_pkg_classes[u.pkg][u.cls] = u

# All exact replacement pairs, longest-first to avoid partial overlap.
exact_pairs = sorted(fqcn_map.items(), key=lambda x: len(x[0]), reverse=True)

# Rewrite each Java unit and add only imports justified by lexical Java references.
for u in units:
    text = u.text
    # Package declaration.
    if u.new_pkg != u.pkg:
        text = re.sub(rf'(?m)^package\s+{re.escape(u.pkg)};', f'package {u.new_pkg};', text, count=1)
    # Explicit FQCN, reflection/service strings, etc.
    for old, new in exact_pairs:
        text = text.replace(old, new)

    code = strip_comments_and_literals(text)
    imports = list(IMPORT_RE.finditer(text))
    existing_simple = set()
    wildcard_old_packages = []
    for m in imports:
        target = m.group(2)
        if target.endswith('.*'):
            wildcard_old_packages.append(target[:-2])
        else:
            existing_simple.add(target.rsplit('.', 1)[-1])

    needed: set[str] = set()

    # References that used to be available because the class shared the same package.
    for simple, dep in old_pkg_classes.get(u.pkg, {}).items():
        if dep.old_fqcn == u.old_fqcn:
            continue
        if dep.new_pkg == u.new_pkg:
            continue
        if simple in existing_simple:
            continue
        if re.search(rf'\b{re.escape(simple)}\b', code):
            needed.add(dep.new_fqcn)

    # Expand wildcard imports from packages whose classes moved, only for lexically used types.
    remove_import_lines = []
    for old_import_pkg in wildcard_old_packages:
        candidates = old_pkg_classes.get(old_import_pkg, {})
        moved_pkg = old_import_pkg in FORBIDDEN_ROOTS or any(old_import_pkg.startswith(p + '.') for p in FORBIDDEN_ROOTS) or old_import_pkg == V2 or old_import_pkg.startswith(V2 + '.')
        if not moved_pkg:
            continue
        for simple, dep in candidates.items():
            if dep.new_pkg == u.new_pkg or simple in existing_simple:
                continue
            if re.search(rf'\b{re.escape(simple)}\b', code):
                needed.add(dep.new_fqcn)
        remove_import_lines.append(old_import_pkg)

    for old_import_pkg in remove_import_lines:
        text = re.sub(rf'(?m)^import\s+{re.escape(old_import_pkg)}\.\*;\s*\n?', '', text)

    # Do not import a class from the same target package or import self.
    needed = {fq for fq in needed if fq != u.new_fqcn and fq.rsplit('.', 1)[0] != u.new_pkg}
    existing_imports = {m.group(2) for m in IMPORT_RE.finditer(text) if not m.group(2).endswith('.*')}
    needed -= existing_imports

    if needed:
        pm = PACKAGE_RE.search(text)
        if not pm:
            raise RuntimeError(f'Missing package after rewrite: {u.path}')
        insertion = '\n\n' + '\n'.join(f'import {fq};' for fq in sorted(needed))
        text = text[:pm.end()] + insertion + text[pm.end():]

    u.new_path.parent.mkdir(parents=True, exist_ok=True)
    u.new_path.write_text(text, encoding='utf-8')

# Remove originals only after all destinations are written.
for u in units:
    if u.path != u.new_path and u.path.exists():
        u.path.unlink()

# Update path/FQCN references in maintained text outside Java too.
TEXT_SUFFIXES = {'.java', '.json', '.md', '.txt', '.yml', '.yaml', '.gradle', '.properties', '.sh', '.py', '.mcfunction', '.toml', '.xml'}
SKIP_PARTS = {'.git', '.gradle', 'build', 'run', 'logs', 'cache', 'caches'}
replacements = sorted(list(fqcn_map.items()) + list(path_map.items()), key=lambda x: len(x[0]), reverse=True)
for path in ROOT.rglob('*'):
    if not path.is_file() or any(part in SKIP_PARTS for part in path.parts):
        continue
    if path.suffix.lower() not in TEXT_SUFFIXES and path.name != 'AGENTS.md':
        continue
    try:
        text = path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        continue
    updated = text
    for old, new in replacements:
        updated = updated.replace(old, new)
    if updated != text:
        path.write_text(updated, encoding='utf-8')

# Mixin config package bases must match the new classes while resource filenames/ids stay historical.
mixin_updates = {
    'tide_traits.mixins.json': ('com.redslovesgames.tideborne.mixin.specimen', None),
    'tide_traits.client.mixins.json': ('com.redslovesgames.tideborne.mixin.specimen.client', None),
    'tide_team_journal.mixins.json': ('com.redslovesgames.tideborne.mixin.journal', None),
    'tidebound_compatibility.mixins.json': ('com.redslovesgames.tideborne.mixin.tide', None),
    'tidebound_compatibility.apex.mixins.json': ('com.redslovesgames.tideborne.mixin.compat.apex', 'com.redslovesgames.tideborne.mixin.tide.OptionalCompatMixinPlugin'),
}
for filename, (pkg, plugin) in mixin_updates.items():
    path = ROOT / 'src/main/resources' / filename
    data = json.loads(path.read_text(encoding='utf-8'))
    data['package'] = pkg
    if plugin is not None:
        data['plugin'] = plugin
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')

# Architecture test: Java ownership only, explicitly not serialized namespace strings.
arch = TEST / 'com/redslovesgames/tideborne/architecture/JavaPackageOwnershipArchitectureTest.java'
arch.parent.mkdir(parents=True, exist_ok=True)
arch.write_text(r'''package com.redslovesgames.tideborne.architecture;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;

class JavaPackageOwnershipArchitectureTest {
    private static final Path PRODUCTION_ROOT = Path.of("src/main/java");
    private static final Pattern PACKAGE = Pattern.compile("(?m)^package\\s+([\\w.]+);");
    private static final List<String> FORBIDDEN = List.of(
            "com.redslovesgames.tidetraits",
            "com.redslovesgames.tideteamjournal",
            "com.redslovesgames.tideboundcompatibility",
            "com.redslovesgames.tideborne.fishing.v2");

    @Test
    void activeProductionJavaUsesUnifiedTideborneOwnership() throws IOException {
        List<String> violations = new ArrayList<>();
        try (var paths = Files.walk(PRODUCTION_ROOT)) {
            for (Path source : paths.filter(path -> path.toString().endsWith(".java")).toList()) {
                String text = Files.readString(source);
                Matcher matcher = PACKAGE.matcher(text);
                if (!matcher.find()) {
                    continue;
                }
                String declared = matcher.group(1);
                for (String forbidden : FORBIDDEN) {
                    if (declared.equals(forbidden) || declared.startsWith(forbidden + ".")) {
                        violations.add(source + " -> " + declared);
                    }
                }
                if (source.toString().replace('\\', '/').contains("/tideborne/fishing/v2/")) {
                    violations.add(source + " -> legacy fishing/v2 source path");
                }
            }
        }
        if (!violations.isEmpty()) {
            fail("Forbidden Java ownership remains: " + violations);
        }
    }
}
''', encoding='utf-8')

# Portable structural validator guard. Do not inspect historical serialized namespace literals.
validator = ROOT / 'scripts/validate_repository.sh'
validator_text = validator.read_text(encoding='utf-8')
marker = '# Java package ownership guard'
if marker not in validator_text:
    guard = r'''
# Java package ownership guard
if grep -R -n -E --include='*.java' '^package com\.redslovesgames\.(tidetraits|tideteamjournal|tideboundcompatibility)(\.|;)|^package com\.redslovesgames\.tideborne\.fishing\.v2(\.|;)' src/main/java; then
    echo 'Historical Java package ownership remains in active production source.' >&2
    exit 1
fi
if find src/main/java/com/redslovesgames/tideborne/fishing -type d -path '*/v2' -print -quit 2>/dev/null | grep -q .; then
    echo 'Fishing v2 source path remains in active production source.' >&2
    exit 1
fi
'''
    # Put the guard after strict shell mode if possible.
    idx = validator_text.find('\n', validator_text.find('set -euo pipefail'))
    if idx >= 0:
        validator_text = validator_text[:idx+1] + guard + validator_text[idx+1:]
    else:
        validator_text = guard + '\n' + validator_text
    validator.write_text(validator_text, encoding='utf-8')

# Update current ownership documentation and source-architecture tests. Archived stage-history remains historical.
legacy_arch = TEST / 'com/redslovesgames/tideborne/architecture/LegacyCleanupArchitectureTest.java'
if legacy_arch.exists():
    t = legacy_arch.read_text(encoding='utf-8')
    t = t.replace('src/main/java/com/redslovesgames/tidetraits/mixin/LegacyFishScoreCalculatorMixin.java',
                  'src/main/java/com/redslovesgames/tideborne/mixin/specimen/LegacyFishScoreCalculatorMixin.java')
    t = t.replace('src/main/java/com/redslovesgames/tidetraits/mixin/FishSatchelConversionMixin.java',
                  'src/main/java/com/redslovesgames/tideborne/mixin/specimen/FishSatchelConversionMixin.java')
    legacy_arch.write_text(t, encoding='utf-8')

agents = ROOT / 'AGENTS.md'
if agents.exists():
    t = agents.read_text(encoding='utf-8')
    section_start = t.find('## Package ownership')
    section_end = t.find('## Persistence and compatibility safety', section_start)
    if section_start >= 0 and section_end > section_start:
        replacement = """## Package ownership\n\nKeep all active Java under `com.redslovesgames.tideborne` and use feature ownership beneath that root. Maintained boundaries include `fishing` (with `fishing.specimen`, `fishing.gear`, and `fishing.tide`), `satchel`, `journal`, `discovery`, `ecosystem`, `compat`, `config`, `presentation`, `command`, `network`, `registry`, `mixin`, and `migration.legacy`. Historical specimen compatibility may remain isolated under an explicitly legacy child package until its migration readers can be retired.\n\nSerialized/resource namespaces are separate from Java ownership. Historical IDs such as `tide_traits:*`, `tide_team_journal:*`, and `tidebound_compatibility:*` remain where compatibility requires them.\n\nDo not create new circular dependencies between feature domains.\n\n"""
        t = t[:section_start] + replacement + t[section_end:]
    t = t.replace('- Fabric entrypoint class names\n', '- valid Fabric entrypoint registrations and side-safe class paths\n')
    agents.write_text(t, encoding='utf-8')

arch_doc = ROOT / 'docs/ARCHITECTURE.md'
if arch_doc.exists():
    t = arch_doc.read_text(encoding='utf-8')
    t = t.replace('### `com.redslovesgames.tideborne.fishing.v2`', '### `com.redslovesgames.tideborne.fishing`')
    compat_start = t.find('## Tide and optional-mod compatibility boundary')
    journal_start = t.find('## Team Journal boundary', compat_start)
    if compat_start >= 0 and journal_start > compat_start:
        compat = """## Tide and optional-mod compatibility boundary\n\n### `com.redslovesgames.tideborne.fishing.tide` and `com.redslovesgames.tideborne.compat`\n\nTide-specific fishing adapters live under `fishing.tide`; optional-mod integration lives under `compat` (for example `compat.apex`). Gear-owned Tide equipment behavior lives under `fishing.gear`, while ecosystem behavior such as chum/shark handling lives under `ecosystem`. Version-sensitive Tide mixins live under `tideborne.mixin.tide` when no stable API/event seam can replace them.\n\nUse `docs/TIDE_MIXIN_INVENTORY.md` before modifying Tide-targeting mixins.\n\n"""
        t = t[:compat_start] + compat + t[journal_start:]
    t = t.replace('### `com.redslovesgames.tideteamjournal`', '### `com.redslovesgames.tideborne.journal`')
    traits_start = t.find('## TideTraits and Satchel boundary')
    dep_start = t.find('## Dependency direction', traits_start)
    if traits_start >= 0 and dep_start > traits_start:
        traits = """## Satchel, discovery, presentation, and historical specimen compatibility\n\n### `com.redslovesgames.tideborne.satchel`, `com.redslovesgames.tideborne.discovery`, and `com.redslovesgames.tideborne.fishing.specimen.legacy`\n\nAngler's Satchel ownership lives under `satchel`; discovery persistence lives under `discovery`; rendering/presentation helpers live under `presentation`; specimen transfer and canonical specimen logic live under `fishing.specimen`. Historical Tide Traits codec/model compatibility is isolated under `fishing.specimen.legacy` until later migration cleanup.\n\nThe Satchel is not a canonical specimen generator. It may store, sort, protect, summarize, and present canonical catches after generation. Legacy compatibility paths must remain guarded so they cannot reroll or overwrite a current canonical specimen.\n\n"""
        t = t[:traits_start] + traits + t[dep_start:]
    t = t.replace('Avoid mutually recursive utility dependencies between `tideborne`, `tideteamjournal`, `tidetraits`, and `tideboundcompatibility`.',
                  'Avoid mutually recursive dependencies between Tideborne feature packages. Prefer canonical API and presentation boundaries over cross-feature implementation reach-through.')
    arch_doc.write_text(t, encoding='utf-8')

current = ROOT / 'docs/CURRENT_STATE.md'
if current.exists():
    t = current.read_text(encoding='utf-8')
    start = t.find('The package review keeps the four historical roots')
    end_marker = 'TeamProgressStore directly owns canonical stored-score reads'
    end = t.find(end_marker, start)
    if start >= 0 and end > start:
        replacement = """Active Java ownership is unified under `com.redslovesgames.tideborne`. Canonical fishing uses `fishing` with `fishing.specimen`, `fishing.gear`, and `fishing.tide`; Team Journal uses `journal`; Satchel uses `satchel`; discovery, ecosystem, compatibility, presentation, networking, registry, mixins, and legacy migration use their corresponding feature packages. Historical specimen compatibility that still serves migration/codec needs is explicitly isolated under `fishing.specimen.legacy`.\n\nPersisted identifiers and historical resource namespaces do not move merely because Java packages do. The Java ownership cleanup therefore leaves old save/NBT/component/payload/registry/resource identifiers intact.\n\n"""
        t = t[:start] + replacement + t[end:]
    current.write_text(t, encoding='utf-8')

todo = ROOT / 'docs/TODO.md'
if todo.exists():
    t = todo.read_text(encoding='utf-8')
    t = t.replace('remove the obsolete FishScore self-mixin and inactive Satchel mixin source, and document ownership of the historical package split without a broad rewrite.',
                  'remove the obsolete FishScore self-mixin and inactive Satchel mixin source, then unify active Java ownership under `com.redslovesgames.tideborne` while preserving serialized compatibility identities.')
    t = t.replace('The architecture sequence is now complete. Future cleanup should follow the ownership boundaries established by the internal API, canonical presentation layer, mixin inventory, shared integration services, and Stage 4 package-ownership rules rather than starting a namespace-wide rewrite.',
                  'The architecture sequence is now complete. Future cleanup should follow the unified Tideborne feature ownership established by the internal API, canonical presentation layer, mixin inventory, and shared integration services. Serialized namespace/resource migration remains separate work and is not implied by Java package ownership.')
    todo.write_text(t, encoding='utf-8')

# Concise current-ownership documentation only where appropriate.
ownership_note = '''\n## Current Java package ownership\n\nActive production Java is owned by `com.redslovesgames.tideborne.*`. Canonical fishing code uses `tideborne.fishing` and feature children such as `fishing.specimen`, `fishing.gear`, and `fishing.tide`; Journal, Satchel, discovery, ecosystem, compatibility, presentation, networking, registry, mixin, and legacy migration code use their corresponding Tideborne feature packages. Historical serialized identifiers and resource namespaces remain intentionally unchanged for compatibility.\n'''
for rel in ('docs/INDEX.md',):
    path = ROOT / rel
    if not path.exists():
        continue
    text = path.read_text(encoding='utf-8')
    if '## Current Java package ownership' not in text:
        path.write_text(text.rstrip() + '\n' + ownership_note, encoding='utf-8')

# Remove empty old directories.
for root in SRC_ROOTS:
    for rel in (
        'com/redslovesgames/tidetraits',
        'com/redslovesgames/tideteamjournal',
        'com/redslovesgames/tideboundcompatibility',
        'com/redslovesgames/tideborne/fishing/v2',
    ):
        base = root / rel
        if base.exists():
            for d in sorted([p for p in base.rglob('*') if p.is_dir()], key=lambda p: len(p.parts), reverse=True):
                try: d.rmdir()
                except OSError: pass
            try: base.rmdir()
            except OSError: pass

# Final source ownership scan.
violations = []
for path in MAIN.rglob('*.java'):
    text = path.read_text(encoding='utf-8')
    pm = PACKAGE_RE.search(text)
    if not pm:
        continue
    pkg = pm.group(1)
    if any(pkg == p or pkg.startswith(p + '.') for p in FORBIDDEN_ROOTS) or pkg == V2 or pkg.startswith(V2 + '.'):
        violations.append(f'{path}: {pkg}')
    if '/tideborne/fishing/v2/' in path.as_posix():
        violations.append(f'{path}: legacy path')
if violations:
    raise RuntimeError('Forbidden ownership remains:\n' + '\n'.join(violations))

summary = {
    'production_java_total': sum(1 for _ in MAIN.rglob('*.java')),
    'test_java_total': sum(1 for _ in TEST.rglob('*.java')),
    'production_java_moved': sum(1 for u in units if u.root == MAIN and u.path != u.new_path),
    'test_java_moved': sum(1 for u in units if u.root == TEST and u.path != u.new_path),
    'fqcn_moves': len(fqcn_map),
}
Path('/tmp/tideborne-package-ownership-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
